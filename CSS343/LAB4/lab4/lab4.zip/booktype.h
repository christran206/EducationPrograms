#ifndef BOOKTYPE
#define BOOKTYPE

#include <string>
#include <iostream>
using namespace std;


/////////////////////////////////////////////////////////////////////////////////////
// BookType Class
// A class that describes type of books 
// The descripton includes:
//               -- Y for children
//               -- F for fiction
//               -- P for periodicals
//               -- Can support future additions
// Features:
//      -- allow users to retrieve the type of book
// Assumptions:
//      -- the character value for type of book is valid
//      -- invalid char values are checked and ignored while reading file
//      -- Book type is in it's own class so it can be modified easily for additions
/////////////////////////////////////////////////////////////////////////////////////
class BookType {
public:
    BookType(char);
     ~BookType();
private:
	 char BookTypeAsAChar;

};

#endif

