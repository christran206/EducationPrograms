//---------------------------------------------------------------------------
/*  Edition class:	Detail for a publication Edition such as Softcover and
                    Hardcover for books, DVD and Blue-ray for Movies, etc

Features:
	--Set Editions
    --Get Edition
Assumptions:
	--Editions in its own class to be modifiable without breaking current
        support
*/
//---------------------------------------------------------------------------
enum Editions {
    HARDCOVER = 'H',
    SOFTCOVER = 'S',
};

class Edition {
    Edition(Editions);
    ~Edition();

    void setEdition(Editions);
    Editions getEdition();

private:
    Editions PubEdition;

};