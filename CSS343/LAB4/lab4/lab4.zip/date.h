///////////////////////////////////////////////////////////////////////////////
// Date
//    Contains the Date using Year,Month, Day, Hour, Minute, Second
// Features:
//      -- Functions to return int of Year, Month, Day, Hour, Minute, Second
// Assumptions:
//      -- DATA is given by the file
//      -- DATA is correctly formatted and invalids will be ignore
//     
///////////////////////////////////////////////////////////////////////////////
#ifndef DATE
#define DATE

#include <string>
#include <iostream>
using namespace std;

class Date {
public:
    Date();
     ~Date();

     int getYear();
     void setYear(int);
     int getMonth();
     void setMonth(int);
     int getDay();
     void setDay(int);
     int getHour();
     void setHour(int);
     int getMinute();
     void setMinute(int);
     int getSecond();
     void setSecond(int);

private:
     int year, month, day, hour, minute, second;

};

#endif